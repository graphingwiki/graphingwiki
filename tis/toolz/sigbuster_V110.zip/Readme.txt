DISCLAIMER:

The author will take no responsibility on possible damage the tool might cause.
Use it own your own risk.

COPYRIGHT:

The copyright of this program belongs to Toni Koivunen / TEAMFURRY.COM.
You are not allowed to distribute the software without prior written consent
of the copyright holder. All questions about the software should be directed
to toni@teamfurry.com

BUGS:

Please send all bugs / enhancement requests to either toni@teamfurry.com or 
tf-tools@teamfurry.com

UPDATES:

The databases are updated semi-regularly. New updates as well as new tools are
announced on the tf-tools@teamfurry.com mailing list. If you want to join the list,
please send me a mail. The list is closed since members get access to the download
site where all the tools provided by teamfurry.com are available.