DISCLAIMER:

The author will take no responsibility on possible damage the tool might cause.
Use it own your own risk.

COPYRIGHT:

The copyright of this program belongs to Toni Koivunen.
You are not allowed to distribute the software without prior written consent
of the copyright holder. All questions about the software should be directed
to toni@teamfurry.com